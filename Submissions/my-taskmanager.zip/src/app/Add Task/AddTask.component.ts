import { Component } from '@angular/core';

@Component({
  selector: 'add-task',
  templateUrl: './AddTask.component.html',
  styleUrls: ['./AddTask.component.css']
})
export class AddTask {
  title = 'Add Task';
}
