import { Component } from '@angular/core';

@Component({
  selector: 'update-task',
  templateUrl: './UpdateTask.component.html',
  styleUrls: ['./UpdateTask.component.css']
})
export class UpdateTask {
  title = 'Update Task';
}
