import { Component } from '@angular/core';

@Component({
  selector: 'view-task',
  templateUrl: './ViewTask.component.html',
  styleUrls: ['./ViewTask.component.css']
})
export class ViewTask{
  title = 'View Task';
}
