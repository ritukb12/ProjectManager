import User from '../User'

export const mockUsers: User[] =
[
    {
        user_fname: 'user Af',
        user_lname: 'user Al',
        user_empID :'user A'
    },
    {
        user_fname: 'user Bf',
        user_lname: 'user Bl',
        user_empID :'user B'
    }
];