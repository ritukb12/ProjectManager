import Project from '../Project'

export const mockProjects: Project[] =
[
    {
        Project_name: "proj A" ,
        start_date: '12-11-2019',
        end_date:'12-12-2019',
        priority: '1' ,
        projectended: false,
        manager_ID : '123' 
    },
    {
        Project_name: "proj B" ,
        start_date: '12-1-2019',
        end_date:'12-2-2019',
        priority: '11' ,
        projectended: true,
        manager_ID : '12345' 
    }
];