export default class User {    
    user_fname: String ;
    user_lname: String ;
    user_empID :String 
  }

  