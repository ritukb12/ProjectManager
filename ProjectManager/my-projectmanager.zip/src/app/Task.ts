export default class Task {
    task_name: String;
    parent_task_name: String;
    start_date: String;
    end_date: String;
    priority: String
  }

  