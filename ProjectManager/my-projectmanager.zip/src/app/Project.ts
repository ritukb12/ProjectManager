export default class Project {
    Project_name: String ;
    start_date: String ;
    end_date:String;
    priority: String ;
    projectended: boolean;
    manager_ID : String ;
}

